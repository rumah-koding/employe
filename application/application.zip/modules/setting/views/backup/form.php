<div class="row">
	<div class="col-md-12">
		<div id="message"></div>
	</div>
</div>