<link rel="stylesheet" href="<?= base_url('asset/plugins/wizard/css/smart_wizard.min.css'); ?>" />
<link rel="stylesheet" href="<?= base_url('asset/plugins/wizard/css/smart_wizard_theme_arrows.min.css'); ?>" />
<style>.sw-theme-arrows{border-radius:0px !important;}.sw-theme-arrows>ul.step-anchor{border-radius:0px !important;}</style>